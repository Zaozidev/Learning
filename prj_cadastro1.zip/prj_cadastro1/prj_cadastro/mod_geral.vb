﻿Module mod_geral
    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public diretorio, sql, aux_cpf, resp As String  'Declaração de Variáveis
    Public cont As Integer
    Public dir_banco = Application.StartupPath & "\Banco\cadastro.mdb"


    Sub Conecta_banco_access()
        Try
            'String de Conexão SQL-SERVER
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & dir_banco)
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub


    Sub Conectar_banco()
        Try
            'String de Conexão SQL-SERVER
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB;Data Source=SALA07\SQLEXPRESS;Initial Catalog=cad_clientes_adsma2;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

    Sub conecta_banco_mysql()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=localhost;DATABASE=cad_clientes;UID=root;PWD=usbw;PORT=3307;OPTION=3;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        Catch ex As Exception
            MsgBox("Erro ao Conectar: " & ex.Message, MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
    Public Function Autenticar_usuario(ByVal usuario As String, ByVal senha As String) As Boolean
        Try
            Dim conn As New ADODB.Connection
            conn.Open("DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=localhost;DATABASE=cad_clientes;UID=root;PWD=usbw;PORT=3307;OPTION=3;")

            Dim rs As New ADODB.Recordset
            Dim sql As String = "SELECT * FROM Login WHERE Usuario='" & usuario & "' AND Senha='" & senha & "' AND Status ='ATIVO'"
            rs.Open(sql, conn)

            If Not rs.EOF Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MsgBox("Erro ao autenticar: " & ex.Message, MsgBoxStyle.Critical)
            Return False
        End Try
    End Function

    Sub Carregar_dados()
        With frm_cadastro.dgv_dados
            sql = "select * from tb_clientes order by nome asc"
            rs = db.Execute(sql)
            cont = 1
            .Rows.Clear()
            Do While rs.EOF = False
                .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, Nothing, Nothing)
                rs.MoveNext()
                cont += 1
            Loop
        End With
    End Sub

    Sub Carregar_tipo_dados()
        With frm_cadastro.cmb_campo.Items
            .Add("CPF")
            .Add("NOME")
        End With
        frm_cadastro.cmb_campo.SelectedIndex = 1
    End Sub

End Module
