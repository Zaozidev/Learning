﻿Imports System.Data.SqlClient

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Frm_Adm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Dgv_Controle = New System.Windows.Forms.DataGridView()
        Me.Usuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lbl_Adm = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CadastroDeClientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormulariioDeCadastroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btn_Pesquisar = New System.Windows.Forms.Button()
        Me.txt_Consulta_Usuario = New System.Windows.Forms.TextBox()
        Me.lbl_Consulta_Usuario = New System.Windows.Forms.Label()
        Me.btn_Limpar = New System.Windows.Forms.Button()
        CType(Me.Dgv_Controle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Dgv_Controle
        '
        Me.Dgv_Controle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgv_Controle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Usuario, Me.Status})
        Me.Dgv_Controle.Location = New System.Drawing.Point(94, 176)
        Me.Dgv_Controle.Name = "Dgv_Controle"
        Me.Dgv_Controle.RowHeadersWidth = 62
        Me.Dgv_Controle.Size = New System.Drawing.Size(344, 201)
        Me.Dgv_Controle.TabIndex = 0
        '
        'Usuario
        '
        Me.Usuario.HeaderText = "Usuario"
        Me.Usuario.MinimumWidth = 8
        Me.Usuario.Name = "Usuario"
        Me.Usuario.Width = 150
        '
        'Status
        '
        Me.Status.HeaderText = "Status"
        Me.Status.MinimumWidth = 8
        Me.Status.Name = "Status"
        Me.Status.Width = 150
        '
        'lbl_Adm
        '
        Me.lbl_Adm.AutoSize = True
        Me.lbl_Adm.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Adm.Location = New System.Drawing.Point(116, 47)
        Me.lbl_Adm.Name = "lbl_Adm"
        Me.lbl_Adm.Size = New System.Drawing.Size(305, 22)
        Me.lbl_Adm.TabIndex = 1
        Me.lbl_Adm.Text = "Controle de acesso de usuarios"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastroDeClientesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(533, 24)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CadastroDeClientesToolStripMenuItem
        '
        Me.CadastroDeClientesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormulariioDeCadastroToolStripMenuItem})
        Me.CadastroDeClientesToolStripMenuItem.Name = "CadastroDeClientesToolStripMenuItem"
        Me.CadastroDeClientesToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.CadastroDeClientesToolStripMenuItem.Text = "Consulta de Clientes"
        '
        'FormulariioDeCadastroToolStripMenuItem
        '
        Me.FormulariioDeCadastroToolStripMenuItem.Name = "FormulariioDeCadastroToolStripMenuItem"
        Me.FormulariioDeCadastroToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.FormulariioDeCadastroToolStripMenuItem.Text = "Formulario de Cadastro"
        '
        'btn_Pesquisar
        '
        Me.btn_Pesquisar.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Pesquisar.Location = New System.Drawing.Point(130, 394)
        Me.btn_Pesquisar.Name = "btn_Pesquisar"
        Me.btn_Pesquisar.Size = New System.Drawing.Size(98, 36)
        Me.btn_Pesquisar.TabIndex = 5
        Me.btn_Pesquisar.Text = "Pesquisar"
        Me.btn_Pesquisar.UseVisualStyleBackColor = True
        '
        'txt_Consulta_Usuario
        '
        Me.txt_Consulta_Usuario.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Consulta_Usuario.Location = New System.Drawing.Point(165, 119)
        Me.txt_Consulta_Usuario.Name = "txt_Consulta_Usuario"
        Me.txt_Consulta_Usuario.Size = New System.Drawing.Size(333, 26)
        Me.txt_Consulta_Usuario.TabIndex = 7
        '
        'lbl_Consulta_Usuario
        '
        Me.lbl_Consulta_Usuario.AutoSize = True
        Me.lbl_Consulta_Usuario.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Consulta_Usuario.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Consulta_Usuario.Location = New System.Drawing.Point(12, 122)
        Me.lbl_Consulta_Usuario.Name = "lbl_Consulta_Usuario"
        Me.lbl_Consulta_Usuario.Size = New System.Drawing.Size(153, 19)
        Me.lbl_Consulta_Usuario.TabIndex = 9
        Me.lbl_Consulta_Usuario.Text = "Usuario do cliente:"
        '
        'btn_Limpar
        '
        Me.btn_Limpar.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Limpar.Location = New System.Drawing.Point(303, 394)
        Me.btn_Limpar.Name = "btn_Limpar"
        Me.btn_Limpar.Size = New System.Drawing.Size(98, 36)
        Me.btn_Limpar.TabIndex = 10
        Me.btn_Limpar.Text = "Limpar"
        Me.btn_Limpar.UseVisualStyleBackColor = True
        '
        'Frm_Adm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Beige
        Me.ClientSize = New System.Drawing.Size(533, 466)
        Me.Controls.Add(Me.btn_Limpar)
        Me.Controls.Add(Me.lbl_Consulta_Usuario)
        Me.Controls.Add(Me.txt_Consulta_Usuario)
        Me.Controls.Add(Me.btn_Pesquisar)
        Me.Controls.Add(Me.lbl_Adm)
        Me.Controls.Add(Me.Dgv_Controle)
        Me.Controls.Add(Me.MenuStrip1)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Name = "Frm_Adm"
        Me.Text = "Frm_Adm"
        CType(Me.Dgv_Controle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Dgv_Controle As DataGridView
    Friend WithEvents lbl_Adm As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents CadastroDeClientesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FormulariioDeCadastroToolStripMenuItem As ToolStripMenuItem

    Private Sub Frm_Adm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_mysql()
    End Sub


    Friend WithEvents btn_Pesquisar As Button
    Friend WithEvents txt_Consulta_Usuario As TextBox
    Friend WithEvents lbl_Consulta_Usuario As Label

    Private Sub FormulariioDeCadastroToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FormulariioDeCadastroToolStripMenuItem.Click
        Dim frm As New frm_cadastro
        frm.Show()
    End Sub

    Private Sub lbl_Consulta_Usuario_Click(sender As Object, e As EventArgs) Handles lbl_Consulta_Usuario.Click

    End Sub
    Friend WithEvents btn_Limpar As Button

    Private Sub btn_pesquisar_Click(sender As Object, e As EventArgs) Handles btn_Pesquisar.Click
        Dim nomeUsuario As String = txt_Consulta_Usuario.Text.Trim()

        Dim conn As New ADODB.Connection
        conn.Open("DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=localhost;DATABASE=cad_clientes;UID=root;PWD=usbw;PORT=3307;OPTION=3;")

        Dim rs As New ADODB.Recordset
        Dim sql As String = "SELECT id_Login, Usuario, Cargo, Status FROM login WHERE Usuario LIKE '%" & nomeUsuario & "%'"
        rs.Open(sql, conn)

        ' Limpa a grid antes de preencher
        Dgv_Controle.Rows.Clear()
        Dgv_Controle.Columns.Clear()

        ' Cria as colunas
        Dgv_Controle.Columns.Add("id_Login", "ID")
        Dgv_Controle.Columns.Add("Usuario", "Usuario")
        Dgv_Controle.Columns.Add("Cargo", "Cargo")
        Dgv_Controle.Columns.Add("Status", "Status")

        ' Preenche linha por linha
        Do While Not rs.EOF
            Dgv_Controle.Rows.Add(rs("id_Login").Value, rs("Usuario").Value, rs("Cargo").Value, rs("Status").Value)
            rs.MoveNext()
        Loop
    End Sub
    Private Sub btn_Limpar_Click(sender As Object, e As EventArgs) Handles btn_Limpar.Click
        txt_Consulta_Usuario.Clear()
        Dgv_Controle.DataSource = Nothing
        Dgv_Controle.Rows.Clear()
        Dgv_Controle.Columns.Clear()
    End Sub


    Friend WithEvents Usuario As DataGridViewTextBoxColumn
    Friend WithEvents Status As DataGridViewTextBoxColumn


    Private Sub Dgv_Controle_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles Dgv_Controle.CellClick
        ' Ignora cliques inválidos (como em cabeçalhos ou linha nova)
        If e.RowIndex < 0 OrElse e.RowIndex >= Dgv_Controle.Rows.Count Then Exit Sub
        If e.ColumnIndex <> Dgv_Controle.Columns("Status").Index Then Exit Sub

        Dim linha = Dgv_Controle.Rows(e.RowIndex)
        Dim idUsuario = linha.Cells("id_Login").Value
        Dim nomeUsuario = linha.Cells("Usuario").Value
        Dim statusAtual = linha.Cells("Status").Value.ToString().ToLower()

        Dim novoStatus As String
        Dim mensagem As String

        If statusAtual = "ativo" Then
            novoStatus = "bloqueado"
            mensagem = "Deseja bloquear o acesso do usuário '" & nomeUsuario & "'?"
        ElseIf statusAtual = "bloqueado" Then
            novoStatus = "ativo"
            mensagem = "Deseja reativar o acesso do usuário '" & nomeUsuario & "'?"
        Else
            MessageBox.Show("Status desconhecido para o usuário '" & nomeUsuario & "'.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim resposta = MessageBox.Show(mensagem, "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

        If resposta = DialogResult.Yes Then
            Try
                Dim conn As New ADODB.Connection
                conn.Open("DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=localhost;DATABASE=cad_clientes;UID=root;PWD=usbw;PORT=3307;OPTION=3;")

                Dim cmd As New ADODB.Command
                cmd.ActiveConnection = conn
                cmd.CommandText = "UPDATE login SET Status='" & novoStatus & "' WHERE id_Login=" & idUsuario
                cmd.Execute()

                MessageBox.Show("Status atualizado para '" & novoStatus & "'.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                btn_Pesquisar.PerformClick() ' Recarrega a grid
            Catch ex As Exception
                MessageBox.Show("Erro ao atualizar status: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
End Class
