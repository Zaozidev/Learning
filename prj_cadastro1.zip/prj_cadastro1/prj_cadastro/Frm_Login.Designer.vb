﻿Imports MySql.Data.MySqlClient

<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Frm_Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Login))
        Me.Img_login = New System.Windows.Forms.PictureBox()
        Me.lbl_login = New System.Windows.Forms.Label()
        Me.txt_usuario = New System.Windows.Forms.TextBox()
        Me.msk_txt_Senha_login = New System.Windows.Forms.MaskedTextBox()
        Me.llbl_senha = New System.Windows.Forms.Label()
        Me.lbl_usuario = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.Btn_Cadastrar = New System.Windows.Forms.Button()
        CType(Me.Img_login, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Img_login
        '
        Me.Img_login.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Img_login.BackColor = System.Drawing.Color.Transparent
        Me.Img_login.Image = CType(resources.GetObject("Img_login.Image"), System.Drawing.Image)
        Me.Img_login.Location = New System.Drawing.Point(167, 60)
        Me.Img_login.Name = "Img_login"
        Me.Img_login.Size = New System.Drawing.Size(191, 174)
        Me.Img_login.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.Img_login.TabIndex = 0
        Me.Img_login.TabStop = False
        '
        'lbl_login
        '
        Me.lbl_login.AutoSize = True
        Me.lbl_login.BackColor = System.Drawing.Color.Transparent
        Me.lbl_login.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_login.Location = New System.Drawing.Point(226, 237)
        Me.lbl_login.Name = "lbl_login"
        Me.lbl_login.Size = New System.Drawing.Size(61, 25)
        Me.lbl_login.TabIndex = 1
        Me.lbl_login.Text = "Login"
        Me.lbl_login.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt_usuario
        '
        Me.txt_usuario.BackColor = System.Drawing.Color.White
        Me.txt_usuario.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_usuario.Location = New System.Drawing.Point(144, 279)
        Me.txt_usuario.Name = "txt_usuario"
        Me.txt_usuario.Size = New System.Drawing.Size(265, 26)
        Me.txt_usuario.TabIndex = 2
        '
        'msk_txt_Senha_login
        '
        Me.msk_txt_Senha_login.BackColor = System.Drawing.Color.White
        Me.msk_txt_Senha_login.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.msk_txt_Senha_login.Location = New System.Drawing.Point(144, 320)
        Me.msk_txt_Senha_login.Name = "msk_txt_Senha_login"
        Me.msk_txt_Senha_login.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.msk_txt_Senha_login.Size = New System.Drawing.Size(265, 26)
        Me.msk_txt_Senha_login.TabIndex = 3
        '
        'llbl_senha
        '
        Me.llbl_senha.AutoSize = True
        Me.llbl_senha.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llbl_senha.Location = New System.Drawing.Point(62, 320)
        Me.llbl_senha.Name = "llbl_senha"
        Me.llbl_senha.Size = New System.Drawing.Size(64, 19)
        Me.llbl_senha.TabIndex = 4
        Me.llbl_senha.Text = "Senha:"
        '
        'lbl_usuario
        '
        Me.lbl_usuario.AutoSize = True
        Me.lbl_usuario.BackColor = System.Drawing.Color.Transparent
        Me.lbl_usuario.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_usuario.Location = New System.Drawing.Point(63, 283)
        Me.lbl_usuario.Name = "lbl_usuario"
        Me.lbl_usuario.Size = New System.Drawing.Size(75, 19)
        Me.lbl_usuario.TabIndex = 5
        Me.lbl_usuario.Text = "Usuario:"
        '
        'btn_login
        '
        Me.btn_login.BackColor = System.Drawing.Color.Silver
        Me.btn_login.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_login.Location = New System.Drawing.Point(106, 364)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(115, 35)
        Me.btn_login.TabIndex = 6
        Me.btn_login.Text = "Entrar"
        Me.btn_login.UseVisualStyleBackColor = False
        '
        'Btn_Cadastrar
        '
        Me.Btn_Cadastrar.BackColor = System.Drawing.Color.Silver
        Me.Btn_Cadastrar.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cadastrar.Location = New System.Drawing.Point(253, 364)
        Me.Btn_Cadastrar.Name = "Btn_Cadastrar"
        Me.Btn_Cadastrar.Size = New System.Drawing.Size(115, 35)
        Me.Btn_Cadastrar.TabIndex = 7
        Me.Btn_Cadastrar.Text = "Cadastre-se"
        Me.Btn_Cadastrar.UseVisualStyleBackColor = False
        '
        'Frm_Login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Beige
        Me.ClientSize = New System.Drawing.Size(457, 436)
        Me.Controls.Add(Me.Btn_Cadastrar)
        Me.Controls.Add(Me.btn_login)
        Me.Controls.Add(Me.lbl_usuario)
        Me.Controls.Add(Me.llbl_senha)
        Me.Controls.Add(Me.msk_txt_Senha_login)
        Me.Controls.Add(Me.txt_usuario)
        Me.Controls.Add(Me.lbl_login)
        Me.Controls.Add(Me.Img_login)
        Me.Name = "Frm_Login"
        Me.Text = "Frm_Login"
        CType(Me.Img_login, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Img_login As PictureBox
    Friend WithEvents lbl_login As Label
    Friend WithEvents txt_usuario As TextBox
    Friend WithEvents msk_txt_Senha_login As MaskedTextBox
    Friend WithEvents llbl_senha As Label
    Friend WithEvents lbl_usuario As Label
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btn_login As Button

    Private Sub Frm_Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_mysql()
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Dim usuario As String = txt_usuario.Text.Trim()
        Dim senha As String = msk_txt_Senha_login.Text.Trim()

        If Autenticar_usuario(usuario, senha) Then
            If usuario.ToLower = "admin" Then
                MessageBox.Show("Bem-vindo, administrador!")
                Frm_Adm.Show()
            Else
                MessageBox.Show("Login realizado com sucesso.")
                frm_cadastro.Show()
            End If
            Me.Hide()
        Else
            MessageBox.Show("Usuário ou senha inválidos.")
        End If
    End Sub

    Friend WithEvents Btn_Cadastrar As Button

    Private Sub Btn_Cadastrar_Click(sender As Object, e As EventArgs) Handles Btn_Cadastrar.Click
        Dim usuario As String = txt_usuario.Text.Trim()
        Dim senha As String = msk_txt_Senha_login.Text.Trim()

        If usuario = "" OrElse senha = "" Then
            MessageBox.Show("Preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Try
            Dim conn As New ADODB.Connection
            conn.Open("DRIVER={MySQL ODBC 8.0 Unicode Driver};SERVER=localhost;DATABASE=cad_clientes;UID=root;PWD=usbw;PORT=3307;OPTION=3;")

            ' Verifica se o usuário já existe
            Dim rs As New ADODB.Recordset
            rs.Open("SELECT * FROM login WHERE Usuario='" & usuario & "'", conn)

            If Not rs.EOF Then
                MessageBox.Show("Usuário já existe. Escolha outro nome.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            ' Insere novo usuário
            Dim cmd As New ADODB.Command
            cmd.ActiveConnection = conn
            cmd.CommandText = "INSERT INTO login (Usuario, Senha, Status, Cargo) VALUES ('" & usuario & "', '" & senha & "', 'ativo', 'usuario')"
            cmd.Execute()

            MessageBox.Show("Cadastro realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txt_usuario.Clear()
            msk_txt_Senha_login.Clear()
        Catch ex As Exception
            MessageBox.Show("Erro ao cadastrar: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
